document.addEventListener("DOMContentLoaded", function() {
    const servicios = document.querySelectorAll(".servicio");

    servicios.forEach(servicio => {
        servicio.addEventListener("mouseenter", function() {
            this.style.transform = "scale(1.05)";
            this.style.transition = "transform 0.3s";
        });
        servicio.addEventListener("mouseleave", function() {
            this.style.transform = "scale(1)";
        });
    });
});