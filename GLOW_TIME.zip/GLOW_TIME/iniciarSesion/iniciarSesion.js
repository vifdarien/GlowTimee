document.addEventListener("DOMContentLoaded", function () {
    const botonEntrar = document.getElementById("btnEntrar");

    botonEntrar.addEventListener("click", function () {
        let usuario = document.getElementById("usuario").value.trim();
        let contrasena = document.getElementById("contrasena").value.trim();

        if (usuario === "" || contrasena === "") {
            alert("Por favor, ingrese su usuario y contraseña.");
            return;
        }

        alert("¡Inicio de sesión exitoso!");
    });
});