document.addEventListener("DOMContentLoaded", function () {
    const botonRegistrar = document.getElementById("btnRegistrar");
    botonRegistrar.addEventListener("click", function () {
        let primerNombre = document.querySelector('input[placeholder="Primer nombre"]').value.trim();
        let segundoNombre = document.querySelector('input[placeholder="Segundo nombre"]').value.trim();
        let contraseña = document.querySelector('input[placeholder="Contraseña"]').value.trim();
        let correo = document.querySelector('input[placeholder="Correo electrónico"]').value.trim();
        if (primerNombre === "" || contraseña === "" || correo === "") {
            alert("Por favor, complete todos los campos obligatorios.");
            return;
        }
        alert("¡Registro exitoso!");
    });
});