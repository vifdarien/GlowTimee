document.addEventListener("DOMContentLoaded", function() {
    const profesionales = document.querySelectorAll(".profesional");

    profesionales.forEach(profesional => {
        profesional.addEventListener("mouseenter", function() {
            this.style.backgroundColor = "#E5B5C5";
        });

        profesional.addEventListener("mouseleave", function() {
            this.style.backgroundColor = "#FDF8F3";
        });
    });
});
