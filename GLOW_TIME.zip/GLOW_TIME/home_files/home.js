function redirigir(pagina) {
    window.location.href = pagina;
}

document.addEventListener("DOMContentLoaded", function() {
    let mensaje = "¡Bienvenida a Glow Time!";
    let i = 0;

    let intervalo = setInterval(function() {
        document.getElementById("mensajeBienvenida").textContent += mensaje[i];
        i++;
        if (i >= mensaje.length) {
            clearInterval(intervalo);
        }
    }, 100);
});
